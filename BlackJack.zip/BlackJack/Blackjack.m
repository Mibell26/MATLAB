function Blackjack

% BlackJack Final Project

% Simulated version of blackjack following usual rules. For the game, the
% player is dealt two cards face up. The dealer is also dealt two cards,
% one of which is face up and the other is face down. The objective of the
% game is to get your sum of cards to be higher than the dealer�s sum
% without going over 21.


% Make an array to represent the deck of cards

d1 = ['2';'3';'4';'5';'6';'7';'8';'9';' ';'J';'Q';'K';'A'];
d1 = string(d1);
d1(9) = string('10');
d2 = d1;
d3 = d1;
d4 = d1;
newDeck = [d1 d2 d3 d4];
deck = [];

% set global variables to be used later

P1 = [];
P2 = [];
Dealer = [];
cardsLeft = 52;
numHitCards1 = 1;
numHitCards2 = 1;
numHitCardsD = 1;
hitCards1 = [ ];
hitCards2 = [ ];
hitCardsD = [ ];
Dealer2 = [ ];
P1SecondCard = [ ];
isSplit = false;

% Set initial card totals, current bet and earnings to be changed later

turn = 0;
tot1 = 0;
tot2 = 0;
totD = 0;
currentBet = 0;
earnings = 0;
thisHandsBet = currentBet;

% set the screensize and make a title

ss = get(0,'ScreenSize');
fig = figure('Position',ss.*.3);
movegui(fig,'center')
title('Blackjack');

% make editable textboxes to keep track of the player's earnings and the
% current bet

uicontrol('Style','edit','Units','Normalized','Position',...
    [0.02 0.15 0.2 0.1],'FontSize',10,'String', 'Earnings' );
Earn = uicontrol('Style','edit','Units','Normalized','Position',...
    [0.02 0.05 0.2 0.1],'FontSize',10,'String', earnings);
uicontrol('Style','edit','Units','Normalized','Position',...
    [0.8 0.15 0.2 0.1],'FontSize',10,'String', 'Current Bet' );
Bet = uicontrol('Style','edit','Units','Normalized','Position',...
    [0.8 0.05 0.2 0.1],'FontSize',10,'String', currentBet);




% make push buttons for the deal, hit, stand, double down, and split
% functions

uicontrol('Style','pushbutton','Units','Normalized','Position',...
    [0.02 0.9 0.2 0.1],'String','Deal',...
    'Callback',@deal);
uicontrol('Style','pushbutton','Units','Normalized','Position',...
    [0.02 0.8 0.2 0.1],'String','Hit',...
    'Callback',@hit);
uicontrol('Style','pushbutton','Units','Normalized','Position',...
    [0.02 0.7 0.2 0.1],'String','Stand',...
    'Callback',@stand);
uicontrol('Style','pushbutton','Units','Normalized','Position',...
    [0.02 0.6 0.2 0.1],'String','Double Down',...
    'Callback',@doubleDown);
uicontrol('Style','pushbutton','Units','Normalized','Position',...
    [0.02 0.5 0.2 0.1],'String','Split',...
    'Callback',@split);

% make a slider which changes the value of the current bet

uicontrol('Style','edit','Units','Normalized','Position',...
    [0.8 0.9 0.2 0.1],'FontSize',10,'String', 'Change Bet');
uicontrol('Style','slider',...
    'Units','normalized',...
    'Position',[0.8 0.8 0.2 0.1],...
    'Tag','slider1',...
    'UserData',struct('val',0,'diffMax',1),...
    'Callback',@slider_callback);

    function slider_callback(hObj,~)
        % updates the current bet on the screen when the slider
        % is moved
        
        currentBet = hObj.Value*100;
        Bet.String=currentBet;
    end



    function deal(~,~)
        % Makes a new deck of cards to deal and randomly deals two cards to
        % each player. It also calculates the current totals for the dealer
        % and player. If the player recieves a natural, their bet is
        % multiplied by 3/2 and they automatically win unless the dealer
        % also has a natural
        
        % Makes a new deck of cards
        
        deck = newDeck;
        thisHandsBet = currentBet;
        cardsLeft = 52;
        turn = 1;
        P2 = [];
        tot2 = 0;
        isSplit = false;
        
        % get rid of any hit and split cards
        
        if numHitCards1 > 1
            for i = 1: numHitCards1-1
                delete(hitCards1(i));
            end
        end
        numHitCards1 = 1;
        
        if numHitCards2 > 1
            for i = 1: numHitCards2-1
                delete(hitCards2(i));
            end
        end
        numHitCards2 = 1;
        
        if numHitCardsD > 1
            for i = 1: numHitCardsD-1
                delete(hitCardsD(i));
            end
        end
        numHitCardsD = 1;
        
        
        % picks a random number and rounds it up to a whole number, then
        % takes that number and multiplies it by the remaining amount of
        % cards left and finds the card in the deck array with that
        % number's index
        
        randNum1 = ceil(rand*cardsLeft);
        cardsLeft = cardsLeft-1;
        randNum2 = ceil(rand*cardsLeft);
        cardsLeft = cardsLeft-1;
        randNum3 = ceil(rand*cardsLeft);
        cardsLeft = cardsLeft-1;
        randNum4 = ceil(rand*cardsLeft);
        cardsLeft = cardsLeft-1;
        card1 = deck(randNum1);
        deck(randNum1) = [];
        card2 = deck(randNum2);
        deck(randNum2) = [];
        card3 = deck(randNum3);
        deck(randNum3) = [];
        card4 = deck(randNum4);
        deck(randNum4) = [];
        
        % gives each player 2 random cards and finds the total for each
        % player
        
        P1 = [card1 card3];
        P2 = card1;
        Dealer = [card2 card4];
        tot1 = total(P1);
        totD = total(Dealer);
        
        % GUI shows the player's two cards and shows the dealer's first
        % card and hides their seoond card
        
        uicontrol('Style','edit','Units','Normalized','Position',...
            [0.3 0.7 0.08 0.18],'FontSize',16,'String', P1(1) );
        P1SecondCard = uicontrol('Style','edit','Units','Normalized',...
            'Position', [0.4 0.7 0.08 0.18],'FontSize',16,'String', P1(2) );
        uicontrol('Style','edit','Units','Normalized','Position',...
            [0.3 0.3 0.08 0.18],'FontSize',16,'String', Dealer(1) );
        Dealer2 = uicontrol('Style','edit','Units','Normalized','Position',...
            [0.4 0.3 0.08 0.18],'FontSize',16,'String', ' ' );
        
        % checks if the player has a natural. If they do and the other
        % dealer also has a natural, the hand is over. If they do and the
        % dealer doesn't have a natural, the bet is multiplied by 3/2 and
        % the bet is added to the earnings
        
        if tot1 == 21
            Dealer2.String = Dealer(2);
            if totD == 21
                turn = 0;
            else
                thisHandsBet = thisHandsBet*1.5;
                earnings = earnings + thisHandsBet;
                turn = 0;
                Earn.String = earnings;
            end
        end
    end


    function hit(~, ~)
        % Deals an additional card to the player who calls it. Updates the
        % player's total and checks if the player busted
        
        % Checks that the cards have been dealt and the hand isn't over
        
        if turn ~= 0
            
            % follows same process for dealing a random call as the deal
            % function
            
            randNum = ceil(rand*cardsLeft);
            cardsLeft = cardsLeft - 1;
            card = deck(randNum);
            deck(randNum) = [ ];
            
            % deals the card to the right player depending on turn and then
            % checks if they busted
            
            if turn == 1
                P1(end+1) = card;
                
                % GUI shows the hit card
                
                hitCards1(numHitCards1) = uicontrol('Style','edit','Units','Normalized',...
                    'Position', [(0.4+.1*numHitCards1) 0.7 0.08 0.18],...
                    'FontSize',16,'String', P1(end) );
                numHitCards1 = numHitCards1 + 1;
                tot1 = total(P1);
                bust(tot1);
            elseif turn == 2
                P2(end+1) = card;
                
                % GUI shows the hit card
                
                hitCards2(numHitCards2) = uicontrol('Style','edit','Units','Normalized',...
                    'Position', [(0.2+.1*numHitCards2) 0.5 0.08 0.18],...
                    'FontSize',16,'String', P2(end) );
                numHitCards2 = numHitCards2 + 1;
                tot2 = total(P2);
                bust(tot2);
            elseif turn == 3
                Dealer(end+1) = card;
                
                % GUI shows the hit card
                
                hitCardsD(numHitCardsD) = uicontrol('Style','edit','Units','Normalized',...
                    'Position', [(0.4+.1*numHitCardsD) 0.3 0.08 0.18],...
                    'FontSize',16,'String', Dealer(end) );
                numHitCardsD = numHitCardsD + 1;
                totD = total(Dealer);
                bust(totD);
            end
        end
    end


    function stand(~, ~)
        % This function will keep dealing the dealer cards until their
        % total is at least 17
        
        if turn == 1 && isSplit == false
            
            % update the turn to the dealer's turn and show the dealer's
            % 2nd card
            
            turn = 3;
            Dealer2.String = Dealer(2);
            
            % while dealer's total is less than 17, hit(which also checks
            % bust internally)
            
            while totD < 17
                hit;
            end
            
            % end the hand and add/subtract the bet to total earnings
            % according to who has a better hand
            
            if totD < 22
                
                if tot1 > totD
                    win;
                elseif totD > tot1 || (totD == 21 && length(Dealer) == 2)
                    lose;
                else
                    turn = 0;
                end
            end
        elseif turn == 2
            
            % update the turn to the dealer's turn and show dealer's 2nd
            % card
            
            turn = 3;
            Dealer2.String = Dealer(2);
            
            % while dealer's total is less than 17, hit (which also checks
            % bust internally)
            
            while totD < 17
                hit;
            end
            
            % end the hand and add/subtract the bet to total earnings
            % according to who has a better hand
            
            if totD < 22
                
                if tot1 > totD
                    if tot1 < 22
                        win;
                    end
                elseif totD > tot1 || (totD == 21 && length(Dealer) == 2)
                    lose;
                end
                if tot2 > totD
                    win;
                elseif totD > tot2 || (totD == 21 && length(Dealer) == 2)
                    lose;
                else
                    turn = 0;
                end
            end
            
            % if the player has split cards and is done hitting their first
            % set of cards, move to the second set of cards
            
        elseif turn == 1
            turn = 2;
        end
    end



    function doubleDown(~, ~)
        % This function will double the current bet and will only give the
        % player one more card before ending the turn. House rules: can't
        % double down after splitting
        
        % Makes sure that cards have been dealt and that the player hasn't
        % hit yet
        
        if turn == 1 && length(P1) == 2 && isSplit == false
            
            % double the bet, hit and stand
            
            thisHandsBet = 2*thisHandsBet;
            hit;
            stand;
            
        end
    end


    function split(~, ~)
        % If the player has two of the same cards, this function will deal
        % the player one more card for the first card and then they can
        % hit, stand or double down as usual. The same will happen with the
        % next card. House rules: Can only split once per hand
        
        
        % check if the cards have been dealt
        
        if turn == 1 && length(P1) == 2 && isSplit == false
            
            % check if the player's cards are the same
            
            if P1(1) == P1(2)
                
                % set the 1st and 2nd sets of cards to the orginal card and
                % then give each set one more random card from the deck
                
                P2(1) = P1(1);
                randNum1 = ceil(rand*cardsLeft);
                cardsLeft = cardsLeft - 1;
                card1 = deck(randNum1);
                randNum2 = ceil(rand*cardsLeft);
                cardsLeft = cardsLeft - 1;
                card2 = deck(randNum2);
                P1(2) = card1;
                P2(2) = card2;
                
                % GUI to show the new cards
                
                P1SecondCard.String = card1;
                hitCards2(numHitCards2) = uicontrol('Style','edit','Units','Normalized',...
                    'Position', [(0.2+.1*numHitCards2) 0.5 0.08 0.18],...
                    'FontSize',16,'String', P2(1) );
                numHitCards2 = 2;
                hitCards2(numHitCards2) = uicontrol('Style','edit','Units','Normalized',...
                    'Position', [(0.2+.1*numHitCards2) 0.5 0.08 0.18],...
                    'FontSize',16,'String', P2(2) );
                numHitCards2 = 3;
                
                % update the totals
                
                tot1 = total(P1);
                tot2 = total(P2);
                isSplit = true;
            end
            
        end
    end



    function bust(total)
        % Checks if the total is over 21. If it is, then either decrease
        % the player's money by the current bet if the player busted or
        % increase the player's money by the current bet if the dealer
        % busted. Also, set the turn to 0 to end actions until deal is
        % pressed again.
        
        % if the total is greater than 21, check which player's turn and
        % then adds or subtracts the current bet accordingly and end
        % current turn
        
        if total > 21
            if turn == 3
                win;
                turn = 0;
            elseif turn == 1 && isSplit == false
                lose;
                turn = 0;
                Dealer2.String = Dealer(2);
            elseif turn == 2
                lose;
                turn = 0;
                Dealer2.String = Dealer(2);
            else
                lose;
                turn = 2;
            end
        end
    end


    function lose
        % Called when the player loses and dealer wins. The current bet is
        % subtracted from the earnings and is updated in GUI and the hand
        % is over
        
        earnings = earnings - thisHandsBet;
        Earn.String = earnings;
        turn = 0;
    end
    function win
        % Called when the player wins and dealer loses. The current bet is
        % added to the earnings and is updated in GUI and the hand
        % is over
        
        earnings = earnings + thisHandsBet;
        Earn.String = earnings;
        turn = 0;
    end
end
