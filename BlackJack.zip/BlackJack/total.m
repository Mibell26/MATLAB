function number = total(P1)

% function takes in the player's cards and totals them up making
% sure that an ace is treated as an 11 if the total won't be higher
% than 21 and will be treated as a 1 if the total would be a bust

% find the number of cards in hand and number of aces

len = length(P1);
Ace = 0;
numArray = zeros(1,len);

% adds face value for cards 2-10 and 10 for every royalty card
% other than ace; keeps track of number of aces

for i = 1:len
    if P1(i) == 'J' || P1(i)== 'Q' ||P1(i) == 'K'
        numArray(i) = 10;
    elseif P1(i) == 'A'
        Ace = Ace + 1;
    else
        numArray(i) = P1(i);
    end
end

% finds the total for the cards excluding aces

number = sum(numArray);

% adds 11 for aces unless the total will be > 21, then it will add
% 1 for each ace

while(Ace > 1)
    number = number + 1;
    Ace = Ace - 1;
end
if Ace == 1
    if number <= 10
        number = number + 11;
    else
        number = number + 1;
    end
end
end